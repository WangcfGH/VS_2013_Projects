#ifndef COMMOM_H
#define COMMOM_H

#endif // COMMOM_H
#define REGISTER "1"
#define LOGIN "2"
#define MASSAGE "3"
#define PICTURE "4"
#define AUDIO "5"
