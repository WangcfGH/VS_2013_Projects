// read:
// #define READ '0'
#define MSG '0'
#define NAME '1'

// write:
// #define SEND '1'
// #define SEND_MSG '0'
