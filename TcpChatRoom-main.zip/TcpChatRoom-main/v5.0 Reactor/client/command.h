#ifndef COMMOM_H
#define COMMOM_H

#endif // COMMOM_H
#define MSG '0'
#define NAME '1'

#define PORT 8888
#define HOST "81.69.236.101"
