&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在实现了基于远程linux服务器的基本通信后为客户端用QT进行最基本的界面编写，在学习QT的基本语法及特性后，查询TCP相关api开始进行客户端界面的编写

项目展示
----
![a,a](https://github.com/senyucci/TcpChatRoom/blob/main/v3.0/QTclient.png)
